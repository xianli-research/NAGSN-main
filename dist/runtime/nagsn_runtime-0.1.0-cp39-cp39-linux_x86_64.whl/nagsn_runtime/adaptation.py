"""Private correction-adaptation API."""

from internal.workflows.adaptation.adapt_correct_cl import AdaptCorrectCl

__all__ = ["AdaptCorrectCl"]
