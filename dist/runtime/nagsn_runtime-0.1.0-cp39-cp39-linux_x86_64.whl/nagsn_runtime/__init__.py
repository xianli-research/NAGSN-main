"""Stable private-runtime API consumed by the public NAGS package.

This package is a development adapter around the private ``internal`` source.
Public releases must replace it with the separately built ``nagsn-runtime``
binary wheel; they must not include this source package or ``internal``.
"""

API_VERSION = (1, 0)

__all__ = ["API_VERSION"]
