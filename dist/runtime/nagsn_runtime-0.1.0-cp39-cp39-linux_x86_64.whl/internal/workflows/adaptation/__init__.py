"""Private correction-adaptation workflow."""
