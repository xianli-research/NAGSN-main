"""Private end-to-end workflows."""
