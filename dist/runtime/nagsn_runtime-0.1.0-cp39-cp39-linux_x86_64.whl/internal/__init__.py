"""Private development and runtime implementation modules.

This package is excluded from the public source distribution.  Public modules
may use a compiled replacement for selected ``internal.runtime`` components.
"""
